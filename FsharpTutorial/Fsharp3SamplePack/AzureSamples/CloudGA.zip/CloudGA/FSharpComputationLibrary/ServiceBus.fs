﻿namespace ServiceBus

open System
open Microsoft.ServiceBus
open System.ServiceModel

open CloudConstant

[<AutoOpen>]
module StateModule = 
    let mutable canStart = false

[<AutoOpen>]
module Utils = 
    let log x = System.Diagnostics.Trace.WriteLine x

[<ServiceContract(Name = "IEchoContract", Namespace = "http://samples.microsoft.com/ServiceModel/Relay/")>]
type IEchoContract = interface 
    [<OperationContract>]
    abstract member Echo : msg:string -> string
end

type IEchoChannel = interface
    inherit IEchoContract
    inherit IClientChannel
end

[<ServiceBehavior(Name = "EchoService", Namespace = "http://samples.microsoft.com/ServiceModel/Relay/")>]
type EchoService() = class
    interface IEchoContract with
        member this.Echo(msg) = 
            canStart.ToString()
end

[<ServiceContract>]
type IComputationControl = interface
    [<OperationContract>]
    abstract SetCanStart : value:bool -> unit
    [<OperationContract>]
    abstract GetCanStart : unit -> bool
end

[<AutoOpen>]
module ServiceCodeModule = 

    let serviceMain(args) =
        let sharedSecretServiceBusCredential = TransportClientEndpointBehavior()
        sharedSecretServiceBusCredential.TokenProvider <- TokenProvider.CreateSharedSecretTokenProvider(issuerName, issuerSecret);

        let address = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "EchoService");
        let host = new ServiceHost(typeof<EchoService>, address);
        let serviceRegistrySettings = new ServiceRegistrySettings(DiscoveryType.Public);

        host.AddServiceEndpoint(typeof<IEchoContract>, NetTcpRelayBinding(), address) |> ignore

        for endpoint in host.Description.Endpoints do
            endpoint.Behaviors.Add(serviceRegistrySettings);
            endpoint.Behaviors.Add(sharedSecretServiceBusCredential)

        host.Open();    

        while (true) do
            System.Threading.Thread.Sleep(3*1000);
            if canStart then
                log "can start...."
            else
                log "can not start!"

        host.Close()
        ()

    let clientMain(args) = 

        let getChannel (channelFactory:ChannelFactory<IEchoChannel>) = 
            let mutable channel = Unchecked.defaultof<IEchoChannel>
            let waitTime = 2*1000;

            for i in [1..6] do
                try            
                    if channel = Unchecked.defaultof<IEchoChannel> || channel.State <> CommunicationState.Opened then
                        channel <- channelFactory.CreateChannel();
                        channel.Open();                
                        System.Threading.Thread.Sleep (waitTime)
                with e -> 
                    log e.Message
                    System.Threading.Thread.Sleep(waitTime);
            channel

        ServiceBusEnvironment.SystemConnectivity.Mode <- ConnectivityMode.AutoDetect;
        
        let serviceUri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "echoservice");
        let sharedSecretServiceBusCredential = new TransportClientEndpointBehavior();
        sharedSecretServiceBusCredential.TokenProvider <- TokenProvider.CreateSharedSecretTokenProvider(issuerName, issuerSecret);

        let channelFactory = new ChannelFactory<IEchoChannel>("RelayEndpoint", new EndpointAddress(serviceUri));
        channelFactory.Endpoint.Behaviors.Add(sharedSecretServiceBusCredential);

        let mutable channel = getChannel channelFactory
        let waitTime = 2*1000;        

        if channel.State <> CommunicationState.Opened then
            true
        else
            let mutable input = "input string"
            let mutable canContinue = false

            while (input <> String.Empty && not canContinue) do
                try
                    let r = channel.Echo input
                    canContinue <- Convert.ToBoolean r
                    log ("Server echoed: " + r)
                with
                | _ as e->
                    log ("Error: " + e.Message)
                    if channel.State <> CommunicationState.Opened then
                        try channel.Close() with _ -> log "error" 
                        channel <- getChannel channelFactory

                System.Threading.Thread.Sleep(waitTime);

            channel.Close();
            channelFactory.Close();

            canContinue

