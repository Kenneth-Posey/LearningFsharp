﻿module CloudConstant

//let serviceName = "testservice0"
//
//let baseAddress = "http://testservice0.queue.core.windows.net";
//let address = sprintf "%s/%s" baseAddress queueName
//let resultQueueName = "resultqueue"
//let resultAddress = sprintf "%s/%s" baseAddress resultQueueName

// queue
let queueName = "testqueue"
let storageAccount = "taliutestcloud"
let queueUrl = sprintf "http://%s.queue.core.windows.net/%s" storageAccount queueName
let accountKey = "XizVrdmtC6FVwYTBG/k+yjZZN9fVY4B6+rhWcum/+W+Us/LSntbvTDHAGah6WUxor6E4bdXCXGt2/txe5Pst3g=="

// service bus
let serviceNamespace = "testservicebus0"
let issuerName = "owner"
let serviceName = "echoservice"
let issuerSecret = "IWma1R4Gzra874kPbUGKpsHVC3+ghfr43T4GjFqcvRM=";