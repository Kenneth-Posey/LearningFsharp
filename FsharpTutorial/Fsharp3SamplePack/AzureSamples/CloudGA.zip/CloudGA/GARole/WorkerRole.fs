﻿namespace GARole

open System
open System.Collections.Generic
open System.Diagnostics
open System.Linq
open System.Net
open System.Threading
open Microsoft.WindowsAzure
open Microsoft.WindowsAzure.Diagnostics
open Microsoft.WindowsAzure.ServiceRuntime
open Microsoft.WindowsAzure.StorageClient

open EvolutionaryComputation

type WorkerRole() =
    inherit RoleEntryPoint() 

    // This is a sample worker implementation. Replace with your logic.

    let log message kind = Trace.WriteLine(message, kind)
    let mutable q = Unchecked.defaultof<CloudQueue>

    override wr.Run() =

        log "GARole entry point called" "Information"

        let lociFunction() = box(random.Next(10))
        let fitnessF (items:obj list) = 
                items |> Seq.map (System.Convert.ToInt32) |> Seq.sum

        let mutable myPopulation = Population lociFunction 50 10

        while(true) do 
            let myEvolve population = Evolve population RankSelection ShuffleCrossover fitnessF 0.9 0.1
            
            myPopulation <- composite myEvolve 1 myPopulation 
            let bestResult = sprintf "@@@ best result = %A" (maxFitness myPopulation fitnessF)
            
            log bestResult "Information"

            let best = bestIndividual myPopulation fitnessF
            let worst = worstIndividual myPopulation fitnessF
            let s = best.ToString()

            Thread.Sleep(random.Next(5) * 100)
            let msg = q.GetMessage()
            if msg <> null then 
                worst.FromString(msg.AsString, System.Convert.ToInt32 >> box)
                q.DeleteMessage(msg)
            
            let bestStr = best.ToString()
            q.AddMessage(CloudQueueMessage(bestStr))
            log (sprintf "message added %A" (q.RetrieveApproximateMessageCount())) "Information"

    override wr.OnStart() = 

        // Set the maximum number of concurrent connections 
        ServicePointManager.DefaultConnectionLimit <- 12
       
        // set up the queue
        let credential = StorageCredentialsAccountAndKey(CloudConstant.storageAccount, CloudConstant.accountKey);        
            
        q <- CloudQueue(CloudConstant.queueUrl, credential)
        if q.Exists() then q.Clear()
        q.CreateIfNotExist() |> ignore
        

        base.OnStart()
