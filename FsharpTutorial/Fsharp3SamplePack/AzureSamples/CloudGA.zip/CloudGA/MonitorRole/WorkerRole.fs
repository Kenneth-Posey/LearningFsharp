﻿namespace MonitorRole

open System
open System.Collections.Generic
open System.Diagnostics
open System.Linq
open System.Net
open System.Threading
open Microsoft.WindowsAzure
open Microsoft.WindowsAzure.Diagnostics
open Microsoft.WindowsAzure.ServiceRuntime
open Microsoft.WindowsAzure.StorageClient

open Microsoft.ServiceBus
open System.ServiceModel

[<ServiceContract(Name = "IEchoContract", Namespace = "http://samples.microsoft.com/ServiceModel/Relay/")>]
type IEchoContract = interface 
    [<OperationContract>]
    abstract member Echo : unit -> string
end

type IEchoChannel = interface
    inherit IEchoContract
    inherit IClientChannel
end

[<ServiceBehavior(Name = "EchoService", 
    InstanceContextMode = InstanceContextMode.Single,
    Namespace = "http://samples.microsoft.com/ServiceModel/Relay/")>]
type EchoService() = class
    member val Value = "" with get, set
    interface IEchoContract with
        member this.Echo() = 
            this.Value.ToString()
end

type WorkerRole() =
    inherit RoleEntryPoint() 

    // This is a sample worker implementation. Replace with your logic.

    let log message kind = Trace.WriteLine(message, kind)
    let mutable q = Unchecked.defaultof<CloudQueue>
    let answerHost = EchoService();
    let mutable host = Unchecked.defaultof<ServiceHost>

    override wr.OnStop() = 
        host.Close()

    override wr.Run() =

        log "MonitorRole entry point called" "Information"
        while(true) do 
            Thread.Sleep 1000
            log "Monitor Working to clear" "Information"
            log (sprintf "queue length = %A" (q.RetrieveApproximateMessageCount())) "Information"
            if (q.RetrieveApproximateMessageCount() > 3) then
                q.GetMessages(3) |> Seq.iter q.DeleteMessage
            
            let msg = q.GetMessage()
            if msg <> null then
                answerHost.Value <- msg.AsString

    override wr.OnStart() = 

        // Set the maximum number of concurrent connections 
        ServicePointManager.DefaultConnectionLimit <- 12
       
       // set up the queue
        let credential = StorageCredentialsAccountAndKey(CloudConstant.storageAccount, CloudConstant.accountKey);        
            
        q <- CloudQueue(CloudConstant.queueUrl, credential)
        q.CreateIfNotExist() |> ignore

        // start the service bus service
        let serviceNamespace = CloudConstant.serviceNamespace
        let issuerName = CloudConstant.issuerName
        let issuerSecret = CloudConstant.issuerSecret

        let sharedSecretServiceBusCredential = TransportClientEndpointBehavior()
        sharedSecretServiceBusCredential.TokenProvider <- TokenProvider.CreateSharedSecretTokenProvider(issuerName, issuerSecret);

        let address = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, CloudConstant.serviceName);
        host <- new ServiceHost(answerHost, address);
        let serviceRegistrySettings = ServiceRegistrySettings(DiscoveryType.Public);

        for endpoint in host.Description.Endpoints do
            endpoint.Behaviors.Add(serviceRegistrySettings);
            endpoint.Behaviors.Add(sharedSecretServiceBusCredential)

        host.Open();

        base.OnStart()
